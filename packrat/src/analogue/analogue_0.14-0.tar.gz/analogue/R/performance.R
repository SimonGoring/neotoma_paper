`performance` <- function(object, ...) UseMethod("performance")
