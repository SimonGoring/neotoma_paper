`coef.wa` <- function(object, ...) {
  object$coefficients
}
