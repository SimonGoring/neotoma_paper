`fuse` <- function(..., weights = NULL) {
    UseMethod("fuse")
}
