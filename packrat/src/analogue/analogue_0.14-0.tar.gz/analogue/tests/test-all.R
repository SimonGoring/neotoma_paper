## Test `analogue` using the `testthat` package

## Setup
library(testthat)
library(analogue)

## Runs the tests in inst/tests
test_package("analogue")
