.onAttach <- function(...) {
  packageStartupMessage("Bchron v4.0 - see http://mathsci.ucd.ie/~parnell_a/Rpack/Bchron.htm for updates\n")
}